<!-- footer.blade.php -->
<footer class="fixed bottom-0 w-full bg-gradient-to-r from-black to-red-500 text-white p-4 print-hidden shadow-lg">
    <div class="container mx-auto text-center">
        <p>&copy; Sakshi Enterprises {{ date('Y') }}</p>
    </div>
</footer>
